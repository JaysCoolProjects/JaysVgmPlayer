// error-handler.js

function handleError(errorCode) {
    var errorMessage;

    switch (errorCode) {
        case 1:
            errorMessage = "This file type is not supported. Error Code 1";
            break;
        case 2:
            errorMessage = "A decoding error occurred. Try re-uploading the file. Error Code 2";
            break;
        case 3:
            errorMessage = "An error occurred getting the required files. Refresh the page. Error Code 3";
            break;
        case 4:
            errorMessage = "An unknown error occurred. Please refresh the page. Error Code 4";
            break;
        case 5:
            errorMessage = "The service is down. Try again another day! Error Code 5";
            break;
        default:
            errorMessage = "An unexpected error occurred. Error Code 6";
            break;
    }

    alert(errorMessage);
}