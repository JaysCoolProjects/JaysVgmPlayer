// dropdown-handler.js

function populateDropdown() {
    var dropdown = document.getElementById('vgmFileDropdown');

    // Fetch vgz files from the same directory
    fetch('./')
        .then(response => response.json())
        .then(fileList => {
            var uniqueTitles = new Set();

            fileList.forEach(fileName => {
                if (fileName.endsWith('.vgz')) {
                    var title = fileName.replace('.vgz', '');
                    if (!uniqueTitles.has(title)) {
                        uniqueTitles.add(title);
                        var option = document.createElement('option');
                        option.value = fileName;
                        option.text = title;
                        dropdown.add(option);
                    }
                }
            });
        })
        .catch(error => {
            handleError(3); // Error getting required files
            console.error(error);
        });
}